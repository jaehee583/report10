// express
const express = require('express');
const app = express();

// body-parser
app.use(express.urlencoded({expended: true}));
app.use(express.json());

// method-override
const methodOverride = require('method-override')
app.use(methodOverride('_method'));

// mongodb
const MongoClient = require('mongodb').MongoClient;

// ejs
app.set('view engine','ejs');

// 데이터베이스
let bookUrl='mongodb+srv://qwe12321:qwe12321@cluster0.slcuw.mongodb.net/book?retryWrites=true&w=majority';
let book;
MongoClient.connect(bookUrl,(err,result)=>{
  if(err) return console.log('db접근 오류');  
  book=result.db('book');
  //서버오픈
  app.listen(8080,()=>{
    console.log('8080포트 열림');
  })
});

// get index.ejs
app.get('/',(req,res)=>{
  book.collection('book').find().toArray((err,result)=>{
      if(err) return console.log('자료검색 오류');
      res.render('index.ejs',{bookData:result});
  });
})

// get '/write'
app.get('/write',(req,res)=>{
  res.render('write.ejs')
})

// /add POST 자료 DB의 컬랙션에 저장
app.post('/add',(req,res)=>{
  let appTitle = req.body.title;
  let appNumber = parseInt(req.body.number);
  let appPublisher = req.body.publisher;
  let appWriter = req.body.writer;
  // 발행자료 갯수
  book.collection('postcount').findOne({개시물갯수:'개시물갯수'},(err,result)=>{
      if(err) return console.log('개시물갯수 검색실패');
      let totalCount = result.전체갯수;
      // book 자료저장
      book.collection('book').insertOne({_id:totalCount+1, title: appTitle, number: appNumber, publisher: appPublisher, writer: appWriter},(err,result)=>{
          if(err) return console.log('/add 오류');
          console.log('/add 성공');
          book.collection('postcount').updateOne({개시물갯수:'개시물갯수'},{$inc:{전체갯수:1}},(err,result)=>{
              if(err) return console.log('/add 문서갯수 변경오류');
          })
          res.redirect('/');
      })
  });
})

// delete
app.delete('/delete', (req, res) => {
  req.body._id=parseInt(req.body._id)
  book.collection('book').deleteOne({_id:req.body._id},(err,result)=>{
  if(err) return console.log('삭제오류');
  console.log(typeof req.body._id)
  res.status(200)
  })  
})

// get '/update'
app.get('/update/:id',(req,res)=>{
  book.collection('book').findOne({_id:Number(req.params.id)},(err,result)=>{
    res.render('update.ejs',{결과:result})
  })  
})

// /put update
app.put('/put',(req,res)=>{
  let appTitle = req.body.title;
  let appNumber = parseInt(req.body.number);
  let appPublisher = req.body.publisher;
  let appWriter = req.body.writer;
  book.collection('book').updateOne({_id:Number(req.body.id)},{$set:{title:appTitle,number:appNumber,publisher:appPublisher,writer:appWriter}},(err,result)=>{
    // 데이터베이스 변경
    if(err) return console.loe('업데이트 실패');    
    // 시작페이지로 이동
    res.redirect('/')
  })  
})